/*  Ext.ux.PrinterFriendly, Version 0.1
 *  (c) 2008 Steffen Hiller (http://www.extjswithrails.com)
 *
 *  License: Ext.ux.PrinterFriendly is licensed under the terms of
 *  the Open Source LGPL 3.0 license.  Commercial use is permitted to the extent
 *  that the code/component(s) do NOT become part of another Open Source or Commercially
 *  licensed development library or toolkit without explicit permission.
 *
 *  License details: http://www.gnu.org/licenses/lgpl.html
 *
 *  This is an extension for the Ext JS Library, for more information see http://www.extjs.com.
 *--------------------------------------------------------------------------*/

Ext.ux.PrinterViewport = Ext.extend(Ext.Viewport, {
  
    initComponent : function() {
        Ext.Viewport.superclass.initComponent.call(this);
        this.el = Ext.getBody();
        this.el.setHeight = Ext.emptyFn;
        this.el.setWidth = Ext.emptyFn;
        this.el.setSize = Ext.emptyFn;
        this.el.dom.scroll = 'auto';
        this.allowDomMove = false;
        this.autoWidth = true;
        this.autoHeight = true;
    },
    
    destroy : function(){
      layout = this.getLayout()
      if (layout.table){ // only working with table layout for now
        layout.table.remove();
        this.el.removeClass("x-table-layout-ct");
        Ext.getHtml().removeClass("x-printer-viewport");
        this.rendered = false;
      }
    },

    render : function(){
      Ext.getHtml().addClass('x-printer-viewport');
      this.layout = this.initialConfig.layout;
      Ext.Viewport.superclass.render.call(this, this.el);
    }
    
});